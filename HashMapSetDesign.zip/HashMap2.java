package DataStructures;
import java.util.LinkedList;

public class HashMap2<K,V> implements Map2<K, V>
{
	private static int INI_CAPACITY = 8;
	private static int MAX_CAPACITY = 1 << 30;
	private int size = 0;
	private int capacity;
	private static float LOAD_FACTOR = 0.75f;
	private LinkedList<Map2.Entry<K, V>>[] hashTable;

	public HashMap2()
	{
		this(INI_CAPACITY, LOAD_FACTOR);
	}

	public HashMap2(int capacity)
	{
		this(capacity, LOAD_FACTOR);
	}

	public HashMap2(int capacity, float loadFactor)
	{
		if (capacity > MAX_CAPACITY)
			this.capacity = MAX_CAPACITY;
		else // the second capacity is the value passed
			this.capacity = capacityPowerOfTwo(capacity);
		this.LOAD_FACTOR = loadFactor;
		hashTable = new LinkedList[this.capacity];
	}

	private int capacityPowerOfTwo(int capacity)
	{
		int powerOfTwo = 1;
		while (powerOfTwo < capacity)
			powerOfTwo <<= 1; // each bit shifting is equivalent to multiplying
								// 2.
		return powerOfTwo;
	}

	@Override
	public boolean isEmpty()
	{
		return size == 0;
	}

	@Override
	public int size()
	{
		return size;
	}

	@Override
	public void clear()
	{
		size=0;
		removeAllEntries();
	}

	private void removeAllEntries()
	{
		for (int i = 0; i < capacity; i++)
			if (hashTable[i] != null)
				hashTable[i].clear();
	}

	@Override
	public boolean containsKey(K key)
	{
		if (get(key) != null)
			return true;
		else
			return false;
	}

	@Override
	public boolean containsValue(V value)
	{
		for (int i = 0; i < capacity; i++)
		{
			if (hashTable[i] != null)
			{
				LinkedList<Entry<K, V>> bucket = hashTable[i];
				for (Entry<K, V> entry : bucket)
					if (entry.getValue().equals(value))
						return true;
			}
		}
		return false;
	}

	@Override
	public V get(K key)
	{
		int valueIndex = hash(key.hashCode());
		if (hashTable[valueIndex] != null)
		{
			for (Entry<K, V> entry : hashTable[valueIndex])
				if (entry.getKey().equals(key))
					return entry.getValue();
		}
		return null;
	}

	private int hash(int hashCode)
	{
		return hashCode & (capacity - 1);// hashCode % capacity;
	}

	@Override
	public V put(K key, V value)
	{
		int valueIndex = hash(key.hashCode());
		if (get(key) != null) // the value exists in the table.
		{
			for (Entry<K, V> entry : hashTable[valueIndex])
				if (entry.getKey().equals(key))
				{
					V oldValue = entry.getValue();
					entry.value = value;
					return oldValue;
				}
		}
		if (size >= capacity * LOAD_FACTOR)
		{
			if (capacity > MAX_CAPACITY)
				throw new RuntimeException("Capacity Rehash Overflow");
			rehash();
		}
		if (hashTable[valueIndex] == null)
			hashTable[valueIndex] = new LinkedList<Entry<K, V>>();
		hashTable[valueIndex].add(new Map2.Entry<K, V>(key, value));
		size++;
		return value;
	}

	private void rehash()
	{
		capacity <<= 1;
		java.util.Set<Entry<K, V>> entrySet = entrySet();
		hashTable = new LinkedList[capacity];
		size = 0;
		for (Entry<K, V> entry : entrySet)
			put(entry.getKey(), entry.getValue());
	}

	@Override
	public java.util.Set<Map2.Entry<K, V>> entrySet()
	{
		java.util.Set<Map2.Entry<K, V>> entrySet = new java.util.HashSet<>();
		for (int i = 0; i < size; i++)
			if (hashTable[i] != null)
				for (Entry<K, V> entry : hashTable[i])
					entrySet.add(entry);
		return entrySet;
	}

	@Override
	public java.util.Set<V> values()
	{
		java.util.Set<V> valueSet = new java.util.HashSet<>();
		for (int i = 0; i < capacity; i++)
			if (hashTable[i] != null)
				for (Entry<K, V> entry : hashTable[i])
					valueSet.add(entry.getValue());
		return valueSet;
	}

	@Override
	public java.util.Set<K> keys()
	{
		java.util.Set<K> keySet = new java.util.HashSet<>();
		for (int i = 0; i < capacity; i++)
			if (hashTable[i] != null)
				for (Entry<K, V> entry : hashTable[i])
					keySet.add(entry.getKey());
		return keySet;
	}

	@Override
	public void remove(K key)
	{
		int index = hash(key.hashCode());
		if (hashTable[index] != null)
		{
			for (Entry<K, V> entry : hashTable[index])
				if (entry.getKey().equals(key))
				{
					hashTable[index].remove(entry);
					size--;
					break;
				}
		}
	}
	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder("{");
		for(int i=0;i<capacity;i++)
			if(hashTable[i]!=null&&hashTable[i].size()>0)
				for(Entry<K,V> entry: hashTable[i])
					sb.append(entry);
		return sb.append("}").toString();
	}
}

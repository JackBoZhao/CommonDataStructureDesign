package DataStructures;

public interface Set2<E> extends java.lang.Iterable<E>
{
	public boolean contains(E e);
	public boolean add(E e);
	public boolean remove(E e);
	public int size();
	public boolean isEmpty();
	public void clear();
}

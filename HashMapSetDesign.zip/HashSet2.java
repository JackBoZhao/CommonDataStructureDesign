package DataStructures;

import java.util.LinkedList;

public class HashSet2<E> implements Set2<E>
{
	private int size = 0;
	private static int INI_CAPACITY = 8;
	private static int MAX_CAPACITY = 1 << 29;
	private int capacity;
	private static float INI_LOAD_FACTOR = 0.8f;
	private float loadFactor;
	private LinkedList<E>[] hashTable;

	public HashSet2()
	{
		this(INI_CAPACITY, INI_LOAD_FACTOR);
	};

	public HashSet2(int capacity)
	{
		this(capacity, INI_LOAD_FACTOR);
	}

	public HashSet2(int capacity, float loadFactor)
	{
		if (capacity > MAX_CAPACITY)
			this.capacity = MAX_CAPACITY;
		else
			this.capacity = capacityPowerOfTwo(capacity);
		this.loadFactor = loadFactor;
		hashTable = new LinkedList[this.capacity];

	}

	private int capacityPowerOfTwo(int capacity)
	{
		int one = 1;
		while (one < capacity)
		{
			one <<= 1;
		}
		return one;
	}

	@Override
	public boolean contains(E e)
	{
		int valueIndex = hash(e.hashCode());
		if (hashTable[valueIndex] != null)
			for (E data : hashTable[valueIndex])
				if (data.equals(e))
					return true;
		return false;

	}

	@Override
	public boolean add(E e)
	{
		if (contains(e))
			return false;
		if (size + 1 > capacity * loadFactor)
		{
			if (capacity >= MAX_CAPACITY)
				throw new RuntimeException("Capacity Overflow.");
			rehash();
		}
		int valueIndex = hash(e.hashCode());
		if (hashTable[valueIndex] == null)
			hashTable[valueIndex] = new LinkedList<E>();
		hashTable[valueIndex].add(e);
		size++;
		return true;
	}

	private void rehash()
	{
		hashTable = new LinkedList[capacityPowerOfTwo(capacity <<= 1)];
		size = 0;
		java.util.ArrayList<E> arrList = copyToList();
		for (E e : arrList)
			add(e);

	}

	private java.util.ArrayList<E> copyToList()
	{
		java.util.ArrayList<E> arrList = new java.util.ArrayList<>();
		for (int i = 0; i < capacity; i++)
			if (hashTable[i] != null)
				for (E e : hashTable[i])
					arrList.add(e);
		return arrList;
	}

	private int hash(int hashCode)
	{
		return hashCode & (capacity - 1);
	}

	@Override
	public boolean remove(E e)
	{
		if (!contains(e))
			return false;
		int valueIndex = hash(e.hashCode());
		if (hashTable[valueIndex] != null)
			for (E data : hashTable[valueIndex])
				if (e.equals(data))
				{
					hashTable[valueIndex].remove(data);
					break;
				}
		size--;
		return true;
	}

	@Override
	public java.util.Iterator<E> iterator()
	{
		return new HashSet2Iterator(this);
	}

	private class HashSet2Iterator implements java.util.Iterator<E>
	{
		private java.util.ArrayList<E> arrList;
		private HashSet2<E> hashSet;
		private int curr = 0;

		public HashSet2Iterator(HashSet2<E> hashSet)
		{
			this.hashSet = hashSet;
			arrList = copyToList();
		}

		@Override
		public boolean hasNext()
		{
			return curr < arrList.size();
		}

		@Override
		public E next()
		{
			return arrList.get(curr++);
		}

		@Override
		public void remove()
		{
			hashSet.remove(arrList.get(curr));
			arrList.remove(curr);
		}
	}

	@Override
	public int size()
	{
		return size;
	}

	@Override
	public boolean isEmpty()
	{
		return size == 0;
	}

	@Override
	public void clear()
	{
		size = 0;
		removeAll();
	}

	private void removeAll()
	{
		for (int i = 0; i < capacity; i++)
			if (hashTable[i] != null)
				hashTable[i].clear();
	}

	@Override
	public String toString()
	{
		java.util.ArrayList<E> arrList = copyToList();
		StringBuilder sb = new StringBuilder("{");
		for (int i = 0; i < arrList.size() - 1; i++)
			sb.append(arrList.get(i) + " ");
		return sb.append("}").toString();
	}
}

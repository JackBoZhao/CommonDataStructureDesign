package DataStructures;

public interface Map2<K,V>
{
	public boolean isEmpty();
	public int size();
	public void clear();
	public boolean containsKey(K key);
	public boolean containsValue(V v);
	public V get(K key);
	public V put(K key, V value);
	public java.util.Set<Entry<K,V>> entrySet();
	public java.util.Set<V> values();
	public java.util.Set<K> keys();
	public void remove(K key);
	public static class Entry<K,V>
	{
		K key;
		V value;
		public Entry(K key, V value)
		{
			this.key=key;
			this.value=value;
		}
		public K getKey() { return key; }
		public V getValue() { return value; }
		@Override
		public String toString() { return "["+key+", "+value+"]"; }
	}
}

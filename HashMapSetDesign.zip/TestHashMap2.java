package DataStructures;

public class TestHashMap2
{

	public static void main(String[] args)
	{
		HashMap2<String, Character> hashMap=new HashMap2<>();
		hashMap.put("Jack",'A');
		hashMap.put("Joe",'B');
		hashMap.put("Andrew", 'C');
		hashMap.put("Zed", 'D');
		hashMap.put("Tim", 'C');
		hashMap.put("Sam", 'B');
		hashMap.put("Guy", 'A');
		System.out.println("hashMap entries: "+hashMap);
		System.out.println("hashMap contains Jack? "+hashMap.containsKey("Jack"));
		System.out.println("hashMap contains B? "+hashMap.containsValue('B'));
		System.out.println("Tim's grade: "+hashMap.get("Tim"));
		hashMap.remove("Tim");
		System.out.println("After removing Tim: "+hashMap);
		hashMap.put("Andrew", 'A');
		System.out.println("After updating Andrew's grade: "+hashMap);
		hashMap.clear();
		System.out.println("After clear(): "+hashMap);
	}
}

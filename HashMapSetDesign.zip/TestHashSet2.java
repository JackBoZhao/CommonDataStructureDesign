package DataStructures;

public class TestHashSet2
{

	public static void main(String[] args)
	{
		HashSet2<Character> hashSet=new HashSet2<>();
		hashSet.add('J');
		hashSet.add('M');
		hashSet.add('B');
		hashSet.add('T');
		hashSet.add('G');
		hashSet.add('R');
		hashSet.add('Y');
		hashSet.add('J');
		System.out.println("hashSet(size "+hashSet.size()+"): "+hashSet);
		System.out.println("J in set? "+hashSet.contains('J'));
		hashSet.remove('Y');
		System.out.println("To lowercase: ");
		for(Character c: hashSet)
			System.out.print(c.toLowerCase(c)+" ");
		System.out.println("\nAfter clear(): "+hashSet);
	}
}

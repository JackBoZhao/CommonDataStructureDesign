package DataStructures;

public class TestArrayList2
{

	public static void main(String[] args)
	{
		List2<String> alist=new ArrayList2<String>();
		
		alist.add("H");
		System.out.println("1. " + alist);
		
		alist.add(3,"C");
		System.out.println("2. " + alist);
		
		alist.add("D");
		System.out.println("3. " + alist);
		alist.set(1, "I");
		System.out.println("set(index,e): " + alist);
	alist.remove("G");
		System.out.println("4. " + alist);
		alist.remove("C");
		System.out.println("5. " + alist);
		alist.add("B");
		System.out.println("6. " + alist);
		for(String s: alist)
			System.out.print(s.toLowerCase() + " ");

	}

}
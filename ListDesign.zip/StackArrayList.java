package DataStructures;

public class StackArrayList<E> extends LinkedList2<E>
{
	private java.util.ArrayList<E> stackList=new java.util.ArrayList<>();
	
	public int getSize()
	{
		return stackList.size();
	}
	public E peek()
	{
		return stackList.get(getSize()-1);
	}
	public void push(E e)
	{
		stackList.add(e);
	}
	public E pop()
	{
		E popedData=stackList.get(getSize()-1);
		stackList.remove(getSize()-1);
		return popedData;
	}
	public boolean isEmpty()
	{
		return stackList.isEmpty();
	}
	public String toString()
	{
		return "Stack List: " +stackList.toString();
	}
}

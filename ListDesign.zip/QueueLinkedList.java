package DataStructures;

public class QueueLinkedList<E>
{
	private java.util.LinkedList<E> queueList=new java.util.LinkedList<>();
	
	public void enqueue(E e)
	{
		queueList.add(e);
	}
	public E dequeue()
	{
		return queueList.removeFirst();
	}
	public int getSize()
	{
		return queueList.size();
	}
	@Override
	public String toString()
	{
		return "Queue List: " +queueList.toString();
	}
}

package DataStructures;

public class ArrayList2<E> extends AbstractList2<E>
{
	private final int INITIAL_CAPACITY = 8;
	private E[] arrData = (E[]) (new Object[INITIAL_CAPACITY]);

	public ArrayList2()
	{
	}

	public ArrayList2(E[] e)
	{
		for (int i = 0; i < e.length; i++)
			add(e[i]);
	}

	@Override
	public void add(int index, E e)
	{
		ensureSize();
		for (int i = size - 1; i >= index; i--)
			arrData[i + 1] = arrData[i];
		arrData[index] = e;
		size++;
	}

	public void ensureSize()
	{
		if (size >= arrData.length)
		{
			E[] newArrData = (E[]) (new Object[size * 2 + 1]);
			System.arraycopy(arrData, 0, newArrData, 0, size);
			arrData = newArrData;
		}
	}

	@Override
	public boolean contains(E e)
	{
		for (int i = 0; i < size; i++)
			if (arrData[i].equals(e))
				return true;

		return false;
	}

	@Override
	public E get(int index)
	{
		validateIndex(index);
		return arrData[index];
	}

	public void validateIndex(int index)
	{
		if (index < 0 || index >= size)
			throw new IndexOutOfBoundsException("Out of bounds index: " + index);
	}

	@Override
	public int indexOf(E e)
	{
		for (int i = 0; i < size; i++)
			if (arrData[i].equals(e))
				return i;

		return -1;
	}

	@Override
	public int lastIndexOf(E e)
	{
		for (int i = size - 1; i >= 0; i--)
			if (arrData[i].equals(e))
				return i;

		return -1;
	}

	@Override
	public E remove(int index)
	{
		validateIndex(index);
		E removedData = arrData[index];
		for (int i = index; i < size - 1; i++)
		{
			arrData[i] = arrData[i + 1];
		}
		arrData[size - 1] = null;
		size--;
		return removedData;
	}

	@Override
	public E set(int index, E e)
	{
		validateIndex(index);
		E oldData = arrData[index];
		arrData[index] = e;
		return oldData;

	}

	@Override
	public void clear()
	{
		arrData = (E[]) (new Object[INITIAL_CAPACITY]);
		size = 0;
	}

	@Override
	public String toString()
	{
		StringBuffer sb = new StringBuffer("[");
		for (int i = 0; i < size; i++)
		{
			sb.append(arrData[i]);
			if (i < size - 1)
				sb.append(",");
		}
		return sb.append("]").toString();
	}

	public void trimArr()
	{
		if (size < arrData.length)
		{
			E[] newArr = (E[]) (new Object[size]);
			System.arraycopy(arrData, 0, newArr, 0, size);
			arrData = newArr;
		}
	}

	@Override
	public java.util.Iterator<E> iterator()
	{
		return new ArrayList2Iterator();
	}

	private class ArrayList2Iterator implements java.util.Iterator<E>
	{
		private int currIndex = 0;

		@Override
		public boolean hasNext()
		{
			return (currIndex < size);
		}

		@Override
		public E next()
		{
			return arrData[currIndex++];
		}

		@Override
		public void remove()
		{
			ArrayList2.this.remove(currIndex);
		}
	}
}

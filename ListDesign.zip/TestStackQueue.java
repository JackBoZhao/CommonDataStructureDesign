package DataStructures;

public class TestStackQueue
{

	public static void main(String[] args)
	{
		StackArrayList<Character> stack = new StackArrayList<>();
		QueueLinkedList<String> queue =new QueueLinkedList<>();

		stack.push('T');
		System.out.println("1. " +stack);
		stack.push('G');
		System.out.println("2. " +stack);
		stack.push('K');
		stack.push('M');
		stack.push('O');
		System.out.println("3. " +stack);
		System.out.println("4. " +stack.pop());
		System.out.println("5. " +stack.pop());
		System.out.println("6. " +stack+"\n");
		
		queue.enqueue("T");
		System.out.println("1. " +queue);
		queue.enqueue("G");
		System.out.println("2. " +queue);
		queue.enqueue("K");
		queue.enqueue("M");
		System.out.println("3. " +queue);
		System.out.println("4. " +queue.dequeue());
		System.out.println("5. " +queue.dequeue());
		System.out.println("6. " +queue);
	}
}
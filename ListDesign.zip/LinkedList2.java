package DataStructures;

public class LinkedList2<E> extends AbstractList2<E>
{
	private Node<E> head, tail;

	public LinkedList2()
	{
	}

	public LinkedList2(E[] e)
	{
		super(e);
	}

	@Override
	public void add(int index, E e)
	{
		if (index == 0)
			addFirst(e);
		else if (index >= size)
			addLast(e);
		else
		{
			Node<E> curr = head;
			Node<E> insertNode = new Node<>(e);

			for (int i = 0; i < index; i++)
				curr = curr.next;
			insertNode.next = curr.next;
			curr.next = insertNode;
			size++;
		}
	}

	public void addFirst(E e)
	{
		Node<E> node = new Node<>(e);
		node.next = head;
		head = node;
		size++;
		if (tail == null)
			tail = head;
	}

	public void addLast(E e)
	{
		Node<E> node = new Node<>(e);
		if (tail == null)
			head = tail = node;
		else
		{
			tail.next = node;
			tail = tail.next;
		}
		size++;
	}

	@Override
	public void clear()
	{
		size = 0;
		head = tail = null;
	}

	@Override
	public boolean isEmpty()
	{
		return size == 0;
	}

	@Override
	public int size()
	{
		return size;
	}

	@Override
	public boolean contains(E e)
	{
		Node<E> curr = head;
		for (int i = 0; i < size; i++)
		{
			if (curr.e.equals(e))
				return true;
			curr = curr.next;
		}
		return false;
	}

	@Override
	public E get(int index)
	{
		if (!isValidIndex(index))
			return null;
		else
		{
			Node<E> curr = head;
			for (int i = 0; i <= index; i++)
				curr = curr.next;
			return curr.e;
		}
	}

	public E getFirst()
	{
		if (head == null)
			return null;
		else
			return head.e;
	}

	public E getLast()
	{
		if (tail == null)
			return null;
		else
			return tail.e;
	}

	@Override
	public int indexOf(E e)
	{
		Node<E> curr = head;
		for (int i = 0; i < size; i++)
		{
			if (e.equals(curr.e))
				return i;
		}
		return -1;
	}

	@Override
	public int lastIndexOf(E e)
	{
		Node<E> curr = head;
		int lastIndex = 0;
		for (int i = 0; i < size; i++)
		{
			if (e.equals(curr.e))
				lastIndex = i;
			curr = curr.next;
		}
		return lastIndex;
	}

	public boolean isValidIndex(int index)
	{
		if (index < 0 || index >= size)
			return false;
		else
			return true;
	}

	@Override
	public E remove(int index)
	{
		if (!isValidIndex(index))
			return null;
		else if (index == 0)
			return removeFirst();
		else if (index == size)
			return removeLast();
		else
		{
			Node<E> curr = head;
			for (int i = 0; i < index - 1; i++)
				curr = curr.next;

			Node<E> removedNode = curr.next;
			curr.next = curr.next.next;
			size--;
			return removedNode.e;
		}
	}

	public E removeFirst()
	{
		if (size == 0)
			return null;
		else
		{
			Node<E> first = head;
			head = head.next;
			size--;
			if (head == null)
				tail = null;
			return first.e;
		}
	}

	public E removeLast()
	{
		if (size == 0)
			return null;
		else if (size == 1)
		{
			Node<E> last = tail;
			head = tail = null;
			size = 0;
			return last.e;
		}
		else
		{
			Node<E> last = tail;
			Node<E> curr = head;
			for (int i = 0; i < size - 1; i++)
				curr = curr.next;
			tail = curr;
			tail.next = null;
			size--;
			return last.e;
		}
	}

	@Override
	public E set(int index, E e)
	{
		if (index < 0)
			throw new IndexOutOfBoundsException("Invalid Index.");
		else
		{
			Node<E> curr = head;
			for (int i = 0; i < index; i++)
				curr = curr.next;
			Node<E> oldE = curr;
			curr.e = e;
			return oldE.e;
		}
	}

	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder("[");
		Node<E> curr = head;
		for (int i = 0; i < size; i++)
		{
			sb.append(curr.e);
			curr = curr.next;
			if (curr != null)
				sb.append(",");
			else
				sb.append("]");
		}
		return sb.toString();
	}

	@Override
	public java.util.Iterator<E> iterator()
	{
		return new LinkedList2Iterator();
	}

	private class LinkedList2Iterator implements java.util.Iterator<E>
	{
		private Node<E> curr = head;

		@Override
		public boolean hasNext()
		{
			return (curr != null);
		}

		@Override
		public E next()
		{
			E currElement = curr.e;
			curr = curr.next;
			return currElement;
		}

		@Override
		public void remove()
		{
			LinkedList2.this.remove(indexOf(curr.e));
		}
	}

	private static class Node<E>
	{
		public E e;
		public Node<E> next;

		public Node(E e)
		{
			this.e = e;
			next = null;
		}
	}
}

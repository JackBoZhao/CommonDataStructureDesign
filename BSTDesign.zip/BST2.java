package DataStructures;

public class BST2<E extends Comparable<E>> extends AbstractTree2<E>
{
	protected int size = 0;
	protected TreeNode<E> root = null;

	public BST2() {}
	public BST2(E[] objects)
	{
		for (int i = 0; i < objects.length; i++)
			insert(objects[i]);
	}
	@Override
	public boolean insert(E e)
	{
		if (root == null)
			root = creatNewTreeNode(e);
		else
		{
			TreeNode<E> parent = null;
			TreeNode<E> curr = root;
			while (curr != null)
			{
				parent = curr;
				if (e.compareTo(curr.data) < 0)
					curr = curr.left;
				else if (e.compareTo(curr.data) > 0)
					curr = curr.right;
				else
					return false;
			}
			if (e.compareTo(parent.data) < 0)
				parent.left = creatNewTreeNode(e);
			else
				parent.right = creatNewTreeNode(e);
		}
		size++;
		return true;
	}
	protected TreeNode<E> creatNewTreeNode(E e)
	{
		return new TreeNode<>(e);
	}
	@Override
	public boolean search(E e)
	{
		TreeNode<E> curr = root;
		while (curr != null)
		{
			if (e.compareTo(curr.data) < 0)
				curr = curr.left;
			else if (e.compareTo(curr.data) > 0)
				curr = curr.right;
			else
				return true;
		}
		return false;
	}
	@Override
	public boolean delete(E e)
	{
		if (root == null)
			return false;
		else
		{
			TreeNode<E> parent = null;
			TreeNode<E> curr = root;
			while (!(e.compareTo(curr.data) == 0))
			{
				parent = curr;
				if (e.compareTo(curr.data) < 0)
					curr = curr.left;
				else if (e.compareTo(curr.data) > 0)
					curr = curr.right;
			}
			if (curr.left == null)
			{
				if (parent == null)
					root = curr.right;
				else
				{
					if (e.compareTo(parent.data) < 0)
						parent.left = curr.right;
					else
						parent.right = curr.right;
				}
			}
			else
			{
				TreeNode<E> parentOfRightMostNode = curr;
				TreeNode<E> rightMostNode = curr.left;
				while (rightMostNode.right != null)
				{
					parentOfRightMostNode = rightMostNode;
					rightMostNode = rightMostNode.right;
				}
				curr.data = rightMostNode.data;
				if (parentOfRightMostNode == curr)
					parentOfRightMostNode.left = rightMostNode.left;
				else
					parentOfRightMostNode.right = rightMostNode.left;
			}
			size--;
			return true;
		}
	}
	@Override
	public void preOrder()
	{
		preOrder(root);
	}
	protected void preOrder(TreeNode<E> root)
	{
		if(root==null)
			return;
		System.out.print(root.data+" ");
		preOrder(root.left);
		preOrder(root.right);
	}
	@Override
	public void inOrder()
	{
		inOrder(root);
	}
	protected void inOrder(TreeNode<E> root)
	{
		if(root==null) return;
		inOrder(root.left);
		System.out.print(root.data+" ");
		inOrder(root.right);
	}
	@Override
	public void postOrder()
	{
		postOrder(root);
	}
	protected void postOrder(TreeNode<E> root)
	{
		if(root==null)
			return;
		postOrder(root.left);
		postOrder(root.right);
		System.out.print(root.data+" ");
	}
	@Override
	public int getSize()
	{
		return size;
	}
	public TreeNode<E> getRoot()
	{
		return root;
	}
	public void clear()
	{
		root=null;
		size=0;
	}
	public java.util.ArrayList<E> path(E e)
	{
		java.util.ArrayList<E> arrList = new java.util.ArrayList<>();
		TreeNode<E> curr=root;
		while(curr!=null)
		{
			arrList.add(curr.data);
			if(e.compareTo(curr.data)<0)
				curr=curr.left;
			else if(e.compareTo(curr.data)>0)
				curr=curr.right;
			else 
				break;
		}
		return arrList;
	}
	@Override
	public java.util.Iterator<E> iterator()
	{
		return new InOrderIterator();
	}
	private class InOrderIterator implements java.util.Iterator<E>
	{
		private java.util.ArrayList<E> arrList = new java.util.ArrayList<>();
		private int index=0;
		
		public InOrderIterator(){ inOrder(); }
		public void inOrder()
		{
			inOrder(root);
		}
		public void inOrder(TreeNode<E> root)
		{
			if(root==null) return;
			inOrder(root.left);
			arrList.add(root.data);
			inOrder(root.right);
		}
		@Override
		public boolean hasNext()
		{
			if(index<arrList.size())
				return true;
			return false;
		}
		@Override
		public E next()
		{
			return arrList.get(index++);
		}
		@Override
		public void remove()
		{
			BST2.this.delete(arrList.get(index));
			arrList.clear();
			inOrder();
		}
	}
	public static class TreeNode<E extends Comparable<E>>
	{
		E data;
		TreeNode<E> left;
		TreeNode<E> right;

		public TreeNode(){ }
		public TreeNode(E e)
		{
			left = null;
			right = null;
			data = e;
		}

	}
}

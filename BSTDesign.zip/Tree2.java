package DataStructures;

public interface Tree2<E> extends Iterable<E>
{
	public boolean search(E e);
	public boolean insert(E e);
	public boolean delete(E e);
	public void inOrder();
	public void preOrder();
	public void postOrder();
	public int getSize();
	public boolean isEmpty();
	public void clear();
}

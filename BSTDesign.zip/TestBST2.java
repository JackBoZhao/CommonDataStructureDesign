package DataStructures;

public class TestBST2
{

	public static void main(String[] args)
	{
		BST2<Character> bst=new BST2<>();
		bst.insert('I');
		bst.insert('M');
		bst.insert('P');
		bst.insert('O');
		bst.insert('R');
		bst.insert('T');
		bst.insert('C');
		bst.insert('A');
		bst.insert('R');
		bst.insert('E');
		bst.insert('F');
		bst.insert('L');
		
		System.out.println("Sorted Inorder: ");
		bst.inOrder();
		System.out.println("\nThis is PostOrder: ");
		bst.postOrder();
		System.out.println("\nAnd PreOrder: ");
		bst.preOrder();
		java.util.ArrayList<Character> pathList=bst.path('T');
		java.util.ArrayList<Character> pathList2=bst.path('V');
	//	java.util.ArrayList<BST2.TreeNode<Character> pathList3=bst.path('L');
		System.out.println("\nPath to T: ");
		for(int i =0;pathList!=null&&i<pathList.size();i++)
			System.out.print(pathList.get(i)+" ");
		System.out.println("\nSearch C: "+bst.search('C'));
		System.out.println("\nSearch V: "+bst.search('V'));
		
		

	}

}

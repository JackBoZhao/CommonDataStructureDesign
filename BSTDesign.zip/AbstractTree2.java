package DataStructures;

public abstract class AbstractTree2<E> implements Tree2<E>
{
	@Override
	public void inOrder(){ }
	@Override
	public void preOrder(){ }
	@Override
	public void postOrder(){ }
	@Override
	public boolean isEmpty()
	{
		return getSize()==0;
	}
}

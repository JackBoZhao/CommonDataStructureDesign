package DataStructures;

public interface Graph2<V>
{
	public int getDegree(int v);
	public void printEdges();
	public void clear();
	public boolean addVertex(V vertex);
	public int getSize();
	public java.util.List<V> getVertices();
	public V getVertex(int index);
	public int getIndex(V v);S
	public java.util.List<Integer> getNeighbors(int index);
	public boolean addEdge(int startV, int endV);
	public AbstractGraph2<V>.Tree dfs(int v);
	public AbstractGraph2<V>.Tree bfs(int v);
}

package DataStructures;
import java.util.*;

public class UnweightedGraph2<V> extends AbstractGraph2<V>
{
	public UnweightedGraph2() { }
	public UnweightedGraph2(V[] vertices, int[][] edgeMatrix)
	{
		super(vertices, edgeMatrix);
	}
	public UnweighteSdGraph2(List<V> vertices, List<Edge> edgeList)
	{
		super(vertices, edgeList);
	}
	public UnweightedGraph2(int[][] edgeMatrix, int numOfVertices)
	{
		super(edgeMatrix, numOfVertices);
	}
	public UnweightedGraph2(List<Edge> edgeList, int numOfVertices)
	{
		super(edgeList, numOfVertices);
	}
}

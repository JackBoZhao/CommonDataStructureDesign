package DataStructures;

import java.util.*;

import com.sun.javafx.geom.Edge;

public abstract class AbstractGraph2<V> implements Graph2<V>
{
	protected List<V> verticesList = new ArrayList<>();
	protected List<List<Edge>> edgeLists = new ArrayList<>();

	// Constructors
	protected AbstractGraph2()
	{
	}

	protected AbstractGraph2(V[] vertices, int[][] edgeMatrix)
	{
		for (int i = 0; i < vertices.length; i++)
			addVertex(vertices[i]);
		addAdjacencyLists(edgeMatrix, vertices.length);
	}

	protected AbstractGraph2(List<V> vertices, List<Edge> edges)
	{
		for (int i = 0; i < vertices.size(); i++)
			addVertex(vertices.get(i));
		addAdjacencyLists(edges);
	}

	protected AbstractGraph2(int[][] edgeMatrix, int numOfVertices)
	{
		for (int i = 0; i < numOfVertices; i++)
			addVertex((V) new Integer(i));
		addAdjacencyLists(edgeMatrix, numOfVertices);
	}

	protected AbstractGraph2(List<Edge> edges, int numOfVertices)
	{
		for (int i = 0; i < numOfVertices; i++)
			addVertex((V) new Integer(i));
		addAdjacencyLists(edges);
	}

	private void addAdjacencyLists(List<Edge> edges)
	{
		for (Edge edge : edges)
			addEdge(edge.startV, edge.endV);
	}

	private void addAdjacencyLists(int[][] edgeMatrix, int numOfVertices)
	{
		for (int i = 0; i < numOfVertices; i++)
			addEdge(edgeMatrix[i][0], edgeMatrix[i][1]);
	}

	@Override
	public boolean addVertex(V vertex)
	{
		if (!verticesList.contains(vertex))
		{
			verticesList.add(vertex);
			edgeLists.add(new ArrayList<Edge>());
			return true;
		}
		else
			return false;
	}

	@Override
	public boolean addEdge(int startV, int endV)
	{
		return addEdge(new Edge(startV, endV));
	}

	protected boolean addEdge(Edge edge)
	{
		if (edge.startV < 0 || edge.startV > getSize() - 1)
			throw new IllegalArgumentException("Illegal Vertex: " + edge.startV);
		if (edge.endV < 0 || edge.endV > getSize() - 1)
			throw new IllegalArgumentException("Illegal Vertex" + edge.endV);
		if (!edgeLists.get(edge.startV).contains(edge))
			edgeLists.get(edge.startV).add(edge);
		else
			return false;
		return true;
	}

	@Override
	public int getSize()
	{
		return verticesList.size();
	}

	@Override
	public V getVertex(int index)
	{
		return verticesList.get(index);
	}

	@Override
	public int getIndex(V v)
	{
		return verticesList.indexOf(v);
	}

	@Override
	public List<V> getVertices()
	{
		return verticesList;
	}

	@Override
	public List<Integer> getNeighbors(int index)
	{
		List<Integer> neighbors = new ArrayList<>();
		for (Edge edge : edgeLists.get(index))
			neighbors.add(edge.endV);
		return neighbors;
	}

	@Override
	public int getDegree(int v)
	{
		return edgeLists.get(v).size();
	}

	@Override
	public void printEdges()
	{
		for (int i = 0; i < edgeLists.size(); i++)
		{
			System.out.print(getVertex(i) + " (" + i + "): ");
			for (Edge edge : edgeLists.get(i))
			{
				System.out.print("(" + getVertex(edge.startV) + ", " + getVertex(edge.endV) + ") ");
			}
			System.out.println();
		}
	}

	@Override
	public void clear()
	{
		verticesList.clear();
		edgeLists.clear();
	}

	@Override
	public Tree dfs(int v)
	{
		List<Integer> searchPath = new ArrayList<>();
		int[] parent = new int[verticesList.size()];
		// set all elements in parent to -1
		for (int i = 0; i < parent.length; i++)
			parent[i] = -1;
		boolean[] isVisited = new boolean[verticesList.size()];
		dfs(v, searchPath, parent, isVisited);

		return new Tree(v, parent, searchPath);
	}

	private void dfs(int startV, List<Integer> searchPath, int[] parent, boolean[] isVisited)
	{
		searchPath.add(startV);
		isVisited[startV] = true;
		for (Edge edge : edgeLists.get(startV))
			if (!isVisited[edge.endV])
			{
				parent[edge.endV] = startV;
				dfs(edge.endV, searchPath, parent, isVisited);
			}
	}
	@Override
	public Tree bfs(int v)
	{
		List<Integer> searchPath=new ArrayList<>();
		int[] parent=new int[verticesList.size()];
		boolean[] isVisited=new boolean[verticesList.size()];
		for(int i=0;i<parent.length;i++)
			parent[i]=-1;
		LinkedList<Integer> queue=new LinkedList<>();
		queue.offer(v);
		isVisited[v]=true;
		
		while(!queue.isEmpty())
		{
			int startV=queue.poll();
			searchPath.add(startV);
			for(Edge edge: edgeLists.get(startV))
				if(!isVisited[edge.endV])
				{
					queue.offer(edge.endV);
					isVisited[edge.endV]=true;
					parent[edge.endV]=startV;
				}
		}S
		return new Tree(v,parent,searchPath);
	}
	public class Tree
	{
		private int[] parent;
		private List<Integer> searchPath;
		private int root;

		public Tree(int root, int[] parent, List<Integer> searchPath)
		{
			this.root = root;
			this.parent = parent;
			this.searchPath = searchPath;
		}

		public int getRoot()
		{
			return this.root;
		}

		public int getParent(int v)
		{
			return parent[v];
		}

		public List<Integer> getSearchPath()
		{
			return searchPath;
		}

		public int getNumOfVerticesFound()
		{
			return searchPath.size();
		}

		// the path from verticesList.get(index) to root
		public List<V> getPath(int index)
		{
			List<V> path = new ArrayList<>();
			do
			{
				path.add(verticesList.get(index));
				index = parent[index];
			} while (index != -1);
			return path;
		}

		// the path from root to verticesList.get(index)
		public void printPath(int index)
		{
			List<V> path = getPath(index);
			System.out.print("The path from" + verticesList.get(root) + " to " + verticesList.get(index) + "is: ");
			for (int i = path.size() - 1; i >= 0; i--)
				System.out.print(path.get(i) + " ");
		}

		public void printTree()
		{
			System.out.println("From root " + verticesList.get(root) + "\nEdges: ");
			for (int i = 0; i < parent.length; i++)
				if (parent[i] != -1)
					System.out.print("(" + verticesList.get(parent[i]) + ", " + verticesList.get(i) + ") ");
			System.out.println();
		}
	}

	public static class Edge
	{
		public int startV, endV;

		public Edge(int startV, int endV)
		{
			this.startV = startV;
			this.endV = endV;
		}

		public boolean equals(Object object)
		{
			return startV == ((Edge) object).startV && endV == ((Edge) object).endV;
		}
	}

}